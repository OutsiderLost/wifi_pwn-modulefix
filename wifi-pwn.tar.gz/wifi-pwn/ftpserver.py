#!/usr/bin/env python
import os
os.sys.path.append('/usr/local/lib/python3.10/dist-packages')
try:
        from pyftpdlib.authorizers import DummyAuthorizer
        from pyftpdlib.handlers import FTPHandler
        from pyftpdlib.servers import FTPServer
except Exception, e:
	print 'Failed to import pyftpdlib:',e
        from pyftpdlib.authorizers import DummyAuthorizer
        from pyftpdlib.handlers import FTPHandler
        from pyftpdlib.servers import FTPServer

# pip install pyftpdlib
# mkdir -p /home/rip
authorizer = DummyAuthorizer()
authorizer.add_user("rip", "ripper", "/home/rip", perm="elradfmw")
authorizer.add_anonymous("/tmp")

handler = FTPHandler
handler.authorizer = authorizer

server = FTPServer(("0.0.0.0", 21), handler)
server.serve_forever()

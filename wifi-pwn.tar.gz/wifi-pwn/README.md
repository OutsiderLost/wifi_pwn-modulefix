pwner
=====

Some scripts for WiFi autopwn

Usage example:
./pwner.py  --pwn -i router_ip -m network_mask -e essid -w wifi_card

## WPA-PSK dictionaries

http://www.proxybay.eu/torrent/5945498/WPA-PSK_WORDLIST_3_Final_%2813_GB%29.rar

## WiFi pinneapple
https://github.com/killuminati2012/wifipineapple/wiki/Quick-Start-Guide